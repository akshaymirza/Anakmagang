<?php
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/about_helper.php';

// Database connection attempt
$conn = null;
if (file_exists(__DIR__ . '/Login/koneksi.php')) {
    include_once __DIR__ . '/Login/koneksi.php';
}

$is_logged_in = is_logged_in();
$is_superadmin = ($is_logged_in && is_superadmin());
$about_file = get_about_file_path();

// POST Handler khusus Superadmin untuk edit data asli
$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_about') {
    if (!$is_superadmin) {
        $msg = 'Hanya Superadmin yang memiliki wewenang untuk memperbarui konten halaman ini!';
        $msg_type = 'danger';
    } else {
        $existing = get_about_content($conn, $about_file);

        $data = [
            'id' => 1,
            'kedayweb_title'       => trim($_POST['kedayweb_title'] ?? ''),
            'kedayweb_description' => trim($_POST['kedayweb_description'] ?? ''),
            'kedayweb_vision'      => trim($_POST['kedayweb_vision'] ?? ''),
            'kedayweb_mission'     => trim($_POST['kedayweb_mission'] ?? ''),
            'kedayweb_image'       => trim($_POST['kedayweb_image'] ?? ''),

            'intern_title'         => trim($_POST['intern_title'] ?? ''),
            'intern_description'   => trim($_POST['intern_description'] ?? ''),
            'intern_benefits'      => trim($_POST['intern_benefits'] ?? ''),
            'intern_workflow'      => trim($_POST['intern_workflow'] ?? ''),
            'intern_image'         => trim($_POST['intern_image'] ?? ''),
            'extra_sections'       => $existing['extra_sections'] ?? [],
            'updated_at'           => date('Y-m-d H:i:s')
        ];

        // Handle Image Uploads if any
        $upload_dir = __DIR__ . '/uploads/about/';
        if (!is_dir($upload_dir)) @mkdir($upload_dir, 0777, true);

        if (isset($_FILES['kedayweb_image_file']) && $_FILES['kedayweb_image_file']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['kedayweb_image_file']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $fname = 'kedayweb_' . time() . '.' . $ext;
                if (move_uploaded_file($_FILES['kedayweb_image_file']['tmp_name'], $upload_dir . $fname)) {
                    $data['kedayweb_image'] = 'uploads/about/' . $fname;
                }
            }
        }

        if (isset($_FILES['intern_image_file']) && $_FILES['intern_image_file']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['intern_image_file']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $fname = 'intern_' . time() . '.' . $ext;
                if (move_uploaded_file($_FILES['intern_image_file']['tmp_name'], $upload_dir . $fname)) {
                    $data['intern_image'] = 'uploads/about/' . $fname;
                }
            }
        }

        // Save through helper (synchronizes MySQL & JSON)
        save_about_content($conn, $about_file, $data);

        $msg = 'Konten Tentang Kedayweb & Anak Magang berhasil diperbarui oleh Superadmin!';
        $msg_type = 'success';
    }
}

$about = get_about_content($conn, $about_file);
$extra_sections = $about['extra_sections'] ?? [];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
    <title>Tentang Kedayweb & Anak Magang</title>
    <!-- Material Symbols -->
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect"/>
    <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
    <link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <!-- Anime.js CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js"></script>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script src="shared-config.js"></script>
    <style>
        body { font-family: Inter, sans-serif; }
        .font-geist { font-family: Geist, sans-serif; }
        /* ── Floating Batik Background Layer ── */
        #batik-layer {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }
        .batik-float {
            position: absolute;
            will-change: transform;
            background-image: url('uploads/Icon/batik-gajah-oling.png');
            background-size: contain;
            background-repeat: no-repeat;
        }
        @media (max-width: 768px) {
            .batik-float {
                max-width: 140px !important;
                max-height: 140px !important;
                opacity: 0.08 !important;
            }
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-900 min-h-screen flex flex-col overflow-x-hidden relative">
    <?php if (!$is_logged_in): ?>
    <!-- ═══ Floating Batik Gajah Oling Background Layer ═══ -->
    <div id="batik-layer" aria-hidden="true">
        <div class="batik-float" style="width:260px;height:260px;top:4%;left:-4%;opacity:0.07;transform:rotate(-15deg)"></div>
        <div class="batik-float" style="width:180px;height:180px;top:12%;right:-2%;opacity:0.05;transform:rotate(22deg)"></div>
        <div class="batik-float" style="width:200px;height:200px;top:52%;left:-3%;opacity:0.07;transform:rotate(-30deg)"></div>
        <div class="batik-float" style="width:240px;height:240px;top:70%;right:-4%;opacity:0.05;transform:rotate(40deg)"></div>
        <div class="batik-float" style="width:150px;height:150px;top:85%;left:25%;opacity:0.06;transform:rotate(-5deg)"></div>
        <div class="batik-float" style="width:320px;height:320px;top:38%;left:55%;opacity:0.06;transform:rotate(8deg)"></div>
        <div class="batik-float" style="width:280px;height:280px;top:25%;left:20%;opacity:0.04;transform:rotate(55deg)"></div>
        <div class="batik-float" style="width:170px;height:170px;top:60%;right:25%;opacity:0.05;transform:rotate(-18deg)"></div>
    </div>
    <?php endif; ?>
    <?php 
    if ($is_logged_in) {
        $active = 'about';
        $user_role = current_user_role();
        if ($user_role === 'admin' || $user_role === 'superadmin') {
            include 'partials/sidebar-admin.php';
        } else {
            include 'partials/sidebar-intern.php';
        }
    } else {
        $nav_icon = 'info';
        $nav_cta_label = 'Masuk Portal';
        include 'partials/topnav-public.php';
    }
    ?>

    <!-- Main Content Area -->
    <main class="<?php echo $is_logged_in ? 'md:ml-[16.5rem]' : ''; ?> flex-1 flex flex-col">
        <!-- Hero Header (Full Width Left to Right) -->
        <section class="w-full bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white py-12 px-6 shadow-md relative overflow-hidden">
            <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
                <?php if ($is_logged_in): ?>
                    <div class="md:hidden">
                        <button onclick="toggleMobileSidebar()" class="px-3 py-2 rounded-lg bg-white/20 text-white flex items-center gap-2 text-sm font-semibold border border-white/30 hover:bg-white/30 transition-all">
                            <span class="material-symbols-outlined">menu</span>
                            <span>Menu Sidebar</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-200 text-xs font-bold border border-blue-400/30 mb-3">
                        <span class="material-symbols-outlined text-sm">verified_user</span>
                        <span>Official Information & Company Profile</span>
                    </span>
                    <h1 class="font-geist text-2xl md:text-4xl font-extrabold tracking-tight">Tentang Kedayweb & Anak Magang</h1>
                    <p class="mt-2 text-slate-300 max-w-2xl text-sm leading-relaxed">
                        Mengenal lebih dekat profil Kedayweb Technology dan ekosistem program magang yang memberdayakan talenta digital muda.
                    </p>
                </div>
                
                <?php if ($is_superadmin): ?>
                    <button onclick="openEditAboutModal()" class="shrink-0 px-6 py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm rounded-xl transition-all shadow-xl flex items-center gap-2 active:scale-95">
                        <span class="material-symbols-outlined text-lg">edit_note</span>
                        <span>Kelola Konten</span>
                    </button>
                <?php endif; ?>
            </div>
        </section>

        <!-- Main Body Content -->
        <div class="w-full max-w-7xl mx-auto p-4 md:p-8 space-y-8 flex-1">

            <!-- Alert Notification -->
            <?php if (!empty($msg)): ?>
                <div class="p-4 rounded-xl <?php echo $msg_type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-red-50 text-red-800 border border-red-200'; ?> flex justify-between items-center text-sm font-medium">
                    <div class="flex items-center gap-2">
                        <span class="material-symbols-outlined"><?php echo $msg_type === 'success' ? 'check_circle' : 'info'; ?></span>
                        <span><?php echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <button onclick="this.parentElement.remove()" class="text-slate-500 hover:text-slate-800">
                        <span class="material-symbols-outlined text-sm">close</span>
                    </button>
                </div>
            <?php endif; ?>

            <!-- Section 1: Tentang Kedayweb -->
            <section class="bg-white rounded-3xl border border-slate-200 p-6 md:p-10 shadow-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div class="lg:col-span-6 space-y-5">
                    <div class="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-100">
                        <span class="material-symbols-outlined text-sm">domain</span>
                        <span>Profil Perusahaan</span>
                    </div>
                    <h2 class="font-geist text-2xl md:text-3xl font-extrabold text-slate-900 leading-tight">
                        <?php echo htmlspecialchars($about['kedayweb_title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                    </h2>
                    <p class="text-slate-600 text-sm md:text-base leading-relaxed">
                        <?php echo nl2br(htmlspecialchars($about['kedayweb_description'] ?? '', ENT_QUOTES, 'UTF-8')); ?>
                    </p>

                    <div class="pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                            <h4 class="font-geist font-bold text-xs uppercase tracking-wider text-blue-700 mb-1 flex items-center gap-1">
                                <span class="material-symbols-outlined text-sm">visibility</span>
                                <span>Visi Utama</span>
                            </h4>
                            <p class="text-xs text-slate-600 leading-relaxed">
                                <?php echo htmlspecialchars($about['kedayweb_vision'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                            </p>
                        </div>
                        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
                            <h4 class="font-geist font-bold text-xs uppercase tracking-wider text-blue-700 mb-1 flex items-center gap-1">
                                <span class="material-symbols-outlined text-sm">flag</span>
                                <span>Misi Utama</span>
                            </h4>
                            <div class="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                                <?php echo htmlspecialchars($about['kedayweb_mission'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="lg:col-span-6 h-80 md:h-[420px] rounded-2xl overflow-hidden shadow-md relative bg-slate-100 group">
                    <img src="<?php echo htmlspecialchars($about['kedayweb_image'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" alt="Profil Kedayweb" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>
                    <div class="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                    <span class="absolute bottom-4 left-4 bg-black/60 backdrop-blur-md text-white font-geist text-xs font-bold px-3 py-1.5 rounded-xl border border-white/20">
                        Kedayweb Technology Workspace
                    </span>
                </div>
            </section>

            <!-- Section 2: Tentang Anak Magang -->
            <section class="bg-white rounded-3xl border border-slate-200 p-6 md:p-10 shadow-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div class="lg:col-span-6 order-2 lg:order-1 h-80 md:h-[420px] rounded-2xl overflow-hidden shadow-md relative bg-slate-100 group">
                    <img src="<?php echo htmlspecialchars($about['intern_image'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" alt="Anak Magang Kedayweb" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>
                    <div class="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                    <span class="absolute bottom-4 left-4 bg-black/60 backdrop-blur-md text-white font-geist text-xs font-bold px-3 py-1.5 rounded-xl border border-white/20">
                        Internship Culture & Community
                    </span>
                </div>

                <div class="lg:col-span-6 order-1 lg:order-2 space-y-5">
                    <div class="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                        <span class="material-symbols-outlined text-sm">groups</span>
                        <span>Ekosistem Intern</span>
                    </div>
                    <h2 class="font-geist text-2xl md:text-3xl font-extrabold text-slate-900 leading-tight">
                        <?php echo htmlspecialchars($about['intern_title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                    </h2>
                    <p class="text-slate-600 text-sm md:text-base leading-relaxed">
                        <?php echo nl2br(htmlspecialchars($about['intern_description'] ?? '', ENT_QUOTES, 'UTF-8')); ?>
                    </p>

                    <div class="pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100">
                            <h4 class="font-geist font-bold text-xs uppercase tracking-wider text-emerald-800 mb-1 flex items-center gap-1">
                                <span class="material-symbols-outlined text-sm">workspace_premium</span>
                                <span>Benefit Magang</span>
                            </h4>
                            <div class="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                                <?php echo htmlspecialchars($about['intern_benefits'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                            </div>
                        </div>
                        <div class="bg-indigo-50/60 p-4 rounded-2xl border border-indigo-100">
                            <h4 class="font-geist font-bold text-xs uppercase tracking-wider text-indigo-800 mb-1 flex items-center gap-1">
                                <span class="material-symbols-outlined text-sm">account_tree</span>
                                <span>Tahapan Alur Kerja</span>
                            </h4>
                            <div class="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                                <?php echo htmlspecialchars($about['intern_workflow'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Bagian & Seksi Tambahan (Hasil Tambah dari Super Admin Panel) -->
            <?php if (!empty($extra_sections)): ?>
                <?php foreach ($extra_sections as $sec): 
                    $sec_style = $sec['style'] ?? 'two_column';
                    $has_img   = !empty($sec['image']);
                ?>
                    <section class="bg-white rounded-3xl border border-slate-200 p-6 md:p-10 shadow-sm overflow-hidden">
                        <?php if ($sec_style === 'two_column'): ?>
                            <div class="grid grid-cols-1 <?php echo $has_img ? 'lg:grid-cols-12' : ''; ?> gap-8 items-center">
                                <div class="<?php echo $has_img ? 'lg:col-span-7' : 'w-full'; ?> space-y-4">
                                    <div class="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-200">
                                        <span class="material-symbols-outlined text-sm"><?php echo htmlspecialchars($sec['icon'] ?? 'info', ENT_QUOTES, 'UTF-8'); ?></span>
                                        <span><?php echo htmlspecialchars($sec['badge'] ?? 'Informasi', ENT_QUOTES, 'UTF-8'); ?></span>
                                    </div>
                                    <h2 class="font-geist text-2xl md:text-3xl font-extrabold text-slate-900 leading-tight">
                                        <?php echo htmlspecialchars($sec['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                    </h2>
                                    <div class="text-slate-600 text-sm md:text-base leading-relaxed whitespace-pre-line">
                                        <?php echo nl2br(htmlspecialchars($sec['content'] ?? '', ENT_QUOTES, 'UTF-8')); ?>
                                    </div>
                                </div>
                                <?php if ($has_img): ?>
                                    <div class="lg:col-span-5 h-72 md:h-96 rounded-2xl overflow-hidden shadow-md relative bg-slate-100 group">
                                        <img src="<?php echo htmlspecialchars($sec['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($sec['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"/>
                                        <div class="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none"></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php elseif ($sec_style === 'card_grid'): ?>
                            <div class="space-y-4">
                                <div class="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                                    <span class="material-symbols-outlined text-sm"><?php echo htmlspecialchars($sec['icon'] ?? 'apartment', ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span><?php echo htmlspecialchars($sec['badge'] ?? 'Informasi', ENT_QUOTES, 'UTF-8'); ?></span>
                                </div>
                                <h2 class="font-geist text-2xl md:text-3xl font-extrabold text-slate-900 leading-tight">
                                    <?php echo htmlspecialchars($sec['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                </h2>
                                <div class="grid grid-cols-1 <?php echo $has_img ? 'lg:grid-cols-12' : ''; ?> gap-6 items-start">
                                    <div class="<?php echo $has_img ? 'lg:col-span-7' : 'w-full'; ?> text-slate-600 text-sm md:text-base leading-relaxed whitespace-pre-line bg-slate-50 p-6 rounded-2xl border border-slate-200/60">
                                        <?php echo nl2br(htmlspecialchars($sec['content'] ?? '', ENT_QUOTES, 'UTF-8')); ?>
                                    </div>
                                    <?php if ($has_img): ?>
                                    <div class="lg:col-span-5 h-72 rounded-2xl overflow-hidden shadow-md bg-slate-100">
                                        <img src="<?php echo htmlspecialchars($sec['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($sec['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="w-full h-full object-cover hover:scale-105 transition-transform duration-500"/>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="relative rounded-2xl overflow-hidden bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-950 text-white p-8 md:p-12 shadow-md">
                                <div class="max-w-3xl space-y-4 relative z-10">
                                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-blue-200 text-xs font-bold border border-white/30">
                                        <span class="material-symbols-outlined text-sm"><?php echo htmlspecialchars($sec['icon'] ?? 'stars', ENT_QUOTES, 'UTF-8'); ?></span>
                                        <span><?php echo htmlspecialchars($sec['badge'] ?? 'Sorotan', ENT_QUOTES, 'UTF-8'); ?></span>
                                    </span>
                                    <h2 class="font-geist text-2xl md:text-4xl font-extrabold tracking-tight">
                                        <?php echo htmlspecialchars($sec['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                    </h2>
                                    <div class="text-slate-200 text-sm md:text-base leading-relaxed whitespace-pre-line">
                                        <?php echo nl2br(htmlspecialchars($sec['content'] ?? '', ENT_QUOTES, 'UTF-8')); ?>
                                    </div>
                                </div>
                                <?php if ($has_img): ?>
                                    <div class="mt-6 rounded-xl overflow-hidden max-h-80 relative z-10 border border-white/20 shadow-lg">
                                        <img src="<?php echo htmlspecialchars($sec['image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($sec['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="w-full h-full object-cover hover:scale-105 transition-transform duration-500"/>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </section>
                <?php endforeach; ?>
            <?php endif; ?>

        </div>

        <div class="shrink-0 mt-auto w-full">
            <?php include 'partials/footer.php'; ?>
        </div>
    </main>

    <!-- Modal Form Edit Konten Asli (Khusus Superadmin) -->
    <?php if ($is_superadmin): ?>
        <div id="editAboutModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 hidden backdrop-blur-sm">
            <div class="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
                <div class="flex justify-between items-center pb-3 border-b border-slate-100 mb-4 sticky top-0 bg-white z-10">
                    <h3 class="font-geist font-bold text-lg text-slate-900 flex items-center gap-2">
                        <span class="material-symbols-outlined text-amber-500">edit_note</span>
                        <span>Edit Konten Tentang Kedayweb & Anak Magang</span>
                    </h3>
                    <button onclick="closeEditAboutModal()" class="text-slate-400 hover:text-slate-600">
                        <span class="material-symbols-outlined">close</span>
                    </button>
                </div>

                <form action="about.php" method="POST" enctype="multipart/form-data" class="space-y-6">
                    <input type="hidden" name="action" value="update_about"/>

                    <!-- Part 1: Kedayweb -->
                    <div class="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                        <h4 class="font-bold text-sm text-blue-700 flex items-center gap-1">
                            <span class="material-symbols-outlined text-base">domain</span>
                            <span>Bagian 1: Profil Kedayweb Technology</span>
                        </h4>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">Judul Profil Perusahaan</label>
                            <input type="text" name="kedayweb_title" value="<?php echo htmlspecialchars($about['kedayweb_title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-blue-600"/>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">Deskripsi Kedayweb</label>
                            <textarea name="kedayweb_description" rows="3" required class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-blue-600"><?php echo htmlspecialchars($about['kedayweb_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1">Visi Perusahaan</label>
                                <textarea name="kedayweb_vision" rows="3" class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-blue-600"><?php echo htmlspecialchars($about['kedayweb_vision'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1">Misi Perusahaan</label>
                                <textarea name="kedayweb_mission" rows="3" class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-blue-600"><?php echo htmlspecialchars($about['kedayweb_mission'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">Upload Foto Kedayweb / Masukkan URL Foto</label>
                            <input type="file" name="kedayweb_image_file" accept="image/*" class="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-xl bg-white mb-2"/>
                            <input type="url" name="kedayweb_image" value="<?php echo htmlspecialchars($about['kedayweb_image'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://..." class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-blue-600"/>
                        </div>
                    </div>

                    <!-- Part 2: Anak Magang -->
                    <div class="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                        <h4 class="font-bold text-sm text-emerald-700 flex items-center gap-1">
                            <span class="material-symbols-outlined text-base">groups</span>
                            <span>Bagian 2: Profil & Ekosistem Anak Magang</span>
                        </h4>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">Judul Program Magang</label>
                            <input type="text" name="intern_title" value="<?php echo htmlspecialchars($about['intern_title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-emerald-600"/>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">Deskripsi Program Magang</label>
                            <textarea name="intern_description" rows="3" required class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-emerald-600"><?php echo htmlspecialchars($about['intern_description'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1">Benefit Magang</label>
                                <textarea name="intern_benefits" rows="3" class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-emerald-600"><?php echo htmlspecialchars($about['intern_benefits'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1">Tahapan Alur Kerja Magang</label>
                                <textarea name="intern_workflow" rows="3" class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-emerald-600"><?php echo htmlspecialchars($about['intern_workflow'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1">Upload Foto Anak Magang / Masukkan URL Foto</label>
                            <input type="file" name="intern_image_file" accept="image/*" class="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-xl bg-white mb-2"/>
                            <input type="url" name="intern_image" value="<?php echo htmlspecialchars($about['intern_image'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://..." class="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl outline-none focus:border-emerald-600"/>
                        </div>
                    </div>

                    <div class="flex flex-col gap-3 pt-3 border-t border-slate-100 sticky bottom-0 bg-white py-2">
                        <a href="admin/superadmin.php#about" class="w-full px-4 py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 border border-blue-200">
                            <span class="material-symbols-outlined text-sm">tune</span>
                            <span>Tambah / Kurangi Bagian & Gambar Baru →</span>
                        </a>
                        <div class="flex justify-end gap-2">
                            <button type="button" onclick="closeEditAboutModal()" class="px-4 py-2 border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer">Batal</button>
                            <button type="submit" class="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold rounded-xl text-xs transition-all shadow-md cursor-pointer">Simpan Perubahan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <script>
            function openEditAboutModal() {
                document.getElementById('editAboutModal').classList.remove('hidden');
            }
            function closeEditAboutModal() {
                document.getElementById('editAboutModal').classList.add('hidden');
            }
        </script>
    <?php endif; ?>
    <?php if (!$is_logged_in): ?>
    <script>
        (function() {
            if (!window.anime) return;
            const floats = document.querySelectorAll('.batik-float');
            if (!floats.length) return;
            const configs = [
                { x: 28, y: 22, r: 8,  dur: 9000  },
                { x: -18, y: 30, r: -6, dur: 11500 },
                { x: 22, y: -18, r: 5,  dur: 8500  },
                { x: -30, y: 20, r: -9, dur: 13000 },
                { x: 25, y: 25, r: 7,   dur: 10000 },
                { x: -20, y: -22, r: -5,dur: 7800  },
                { x: 18, y: 28, r: 10,  dur: 12500 },
                { x: -24, y: -16, r: -7,dur: 9800  }
            ];
            floats.forEach((el, i) => {
                const cfg = configs[i % configs.length];
                const baseRotate = parseFloat(el.style.transform.match(/rotate\(([^)]+)deg\)/)?.[1] || 0);
                anime({
                    targets: el,
                    translateX: [
                        { value:  cfg.x,      duration: cfg.dur * 0.5, easing: 'easeInOutSine' },
                        { value: -cfg.x * 0.6,duration: cfg.dur * 0.5, easing: 'easeInOutSine' }
                    ],
                    translateY: [
                        { value:  cfg.y,      duration: cfg.dur * 0.6, easing: 'easeInOutSine' },
                        { value: -cfg.y * 0.7,duration: cfg.dur * 0.4, easing: 'easeInOutSine' }
                    ],
                    rotate: [
                        { value: baseRotate + cfg.r,       duration: cfg.dur * 0.55, easing: 'easeInOutSine' },
                        { value: baseRotate - cfg.r * 0.5, duration: cfg.dur * 0.45, easing: 'easeInOutSine' }
                    ],
                    loop: true,
                    direction: 'alternate'
                });
            });
        })();
    </script>
    <?php endif; ?>
</body>
</html>
