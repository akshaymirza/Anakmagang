/* Kedayweb – Shared Tailwind Config (single source of truth) */
tailwind.config = {
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        "secondary-fixed": "#dce1ff",
        "surface-container-highest": "#d3e4fe",
        "primary": "#00236f",
        "on-tertiary-fixed": "#341100",
        "on-surface": "#0b1c30",
        "inverse-primary": "#b6c4ff",
        "tertiary-container": "#6e2c00",
        "primary-container": "#1e3a8a",
        "outline": "#757682",
        "on-error-container": "#93000a",
        "surface-bright": "#f8f9ff",
        "on-secondary-fixed-variant": "#374475",
        "surface-tint": "#4059aa",
        "on-tertiary-fixed-variant": "#773205",
        "on-tertiary": "#ffffff",
        "background": "#f8f9ff",
        "secondary-container": "#b7c4fd",
        "tertiary": "#4b1c00",
        "surface-container-low": "#eff4ff",
        "inverse-on-surface": "#eaf1ff",
        "on-tertiary-container": "#f39461",
        "on-primary-container": "#90a8ff",
        "secondary-fixed-dim": "#b7c4fd",
        "on-surface-variant": "#444651",
        "surface-container-high": "#dce9ff",
        "on-background": "#0b1c30",
        "surface": "#f8f9ff",
        "inverse-surface": "#213145",
        "error-container": "#ffdad6",
        "surface-container-lowest": "#ffffff",
        "on-secondary-container": "#435081",
        "surface-dim": "#cbdbf5",
        "tertiary-fixed-dim": "#ffb691",
        "on-secondary": "#ffffff",
        "primary-fixed": "#dce1ff",
        "outline-variant": "#c5c5d3",
        "on-primary-fixed-variant": "#264191",
        "tertiary-fixed": "#ffdbcb",
        "error": "#ba1a1a",
        "on-primary": "#ffffff",
        "secondary": "#4f5c8e",
        "on-secondary-fixed": "#071747",
        "primary-fixed-dim": "#b6c4ff",
        "on-error": "#ffffff",
        "surface-container": "#e5eeff",
        "on-primary-fixed": "#00164e",
        "surface-variant": "#d3e4fe",
        /* aliases used by projects page */
        "brand": "#1e3a8a",
        "canvas": "#f8f9ff",
        "line": "#c5c5d3"
      },
      borderRadius: {
        DEFAULT: "0.25rem",
        lg: "0.5rem",
        xl: "0.75rem",
        "2xl": "1rem",
        full: "9999px"
      },
      spacing: {
        "container-max": "1280px",
        md: "16px",
        base: "4px",
        xs: "4px",
        "3xl": "64px",
        gutter: "24px",
        xl: "32px",
        lg: "24px",
        sm: "8px",
        "2xl": "48px"
      },
      fontFamily: {
        "body-lg": ["Inter", "sans-serif"],
        "body-md": ["Inter", "sans-serif"],
        "body-sm": ["Inter", "sans-serif"],
        "label-md": ["Geist", "sans-serif"],
        "headline-xl": ["Geist", "sans-serif"],
        "headline-md": ["Geist", "sans-serif"],
        "headline-lg-mobile": ["Geist", "sans-serif"],
        "headline-lg": ["Geist", "sans-serif"],
        "label-sm": ["Geist", "sans-serif"],
        geist: ["Geist", "sans-serif"],
        inter: ["Inter", "sans-serif"]
      },
      fontSize: {
        "body-lg": ["18px", { lineHeight: "28px", fontWeight: "400" }],
        "body-md": ["16px", { lineHeight: "24px", fontWeight: "400" }],
        "body-sm": ["14px", { lineHeight: "20px", fontWeight: "400" }],
        "label-md": ["14px", { lineHeight: "16px", letterSpacing: "0.05em", fontWeight: "600" }],
        "headline-xl": ["48px", { lineHeight: "56px", letterSpacing: "-0.02em", fontWeight: "700" }],
        "headline-md": ["20px", { lineHeight: "28px", fontWeight: "600" }],
        "headline-lg-mobile": ["24px", { lineHeight: "32px", fontWeight: "600" }],
        "headline-lg": ["32px", { lineHeight: "40px", letterSpacing: "-0.01em", fontWeight: "600" }],
        "label-sm": ["12px", { lineHeight: "14px", fontWeight: "500" }]
      }
    }
  }
};

// ============================================================
// Timezone Helper: Memaksa waktu selalu mengikuti zona waktu WIB (Asia/Jakarta, UTC+7)
// ============================================================
window.getNowWIB = function(d) {
  const base = (d instanceof Date) ? d : new Date();
  try {
    return new Date(base.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
  } catch (e) {
    return new Date(base.getTime() + (7 * 3600 * 1000) + (base.getTimezoneOffset() * 60000));
  }
};

window.formatDateWIB = function(d = new Date()) {
  const w = window.getNowWIB(d);
  return `${w.getFullYear()}-${String(w.getMonth() + 1).padStart(2, '0')}-${String(w.getDate()).padStart(2, '0')}`;
};

window.formatTimeWIB = function(d = new Date(), withSeconds = false) {
  const w = window.getNowWIB(d);
  const pad = n => String(n).padStart(2, '0');
  return withSeconds
    ? `${pad(w.getHours())}:${pad(w.getMinutes())}:${pad(w.getSeconds())}`
    : `${pad(w.getHours())}:${pad(w.getMinutes())}`;
};
